package com.example.upgradebench;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.ItemAttributeModifierEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Atributos aplicados por evento (compatível com itens de outros mods). */
@Mod.EventBusSubscriber(modid = UpgradeBenchMod.MODID)
public class AttributeEvents {
    @SubscribeEvent
    public static void onAttributes(ItemAttributeModifierEvent e) {
        if (e.getSlotType() != EquipmentSlot.MAINHAND) return;
        CompoundTag tag = e.getItemStack().getTag();
        if (tag == null) return;
        int lvl = tag.getInt(UpgradeData.TAG);
        if (lvl <= 0) return;
        BenchRarity rarity = BenchRarity.get(tag.getInt(UpgradeData.RARITY));

        // dano por nível
        double flat = lvl * UpgradeData.FLAT_BASE + UpgradeData.FLAT_STEP * lvl * (lvl - 1) / 2.0;
        e.addModifier(Attributes.ATTACK_DAMAGE,
                new AttributeModifier(UpgradeData.DAMAGE_UUID, "Bench damage", flat, Operation.ADDITION));
        e.addModifier(Attributes.ATTACK_DAMAGE,
                new AttributeModifier(UpgradeData.MULT_UUID, "Bench multiplier",
                        Math.min(Math.pow(1 + UpgradeData.MULT_PER_LEVEL, lvl), 1.0e9) - 1, Operation.MULTIPLY_TOTAL));

        // dano da raridade
        if (rarity.dmgMult > 1.0) {
            e.addModifier(Attributes.ATTACK_DAMAGE,
                    new AttributeModifier(UpgradeData.RARITY_MULT_UUID, "Bench rarity damage",
                            rarity.dmgMult - 1.0, Operation.MULTIPLY_TOTAL));
        }

        // bônus fixos da raridade
        for (int k = 0; k < rarity.fixed.length; k++) {
            UpgradeData.Bonus b = rarity.fixed[k];
            e.addModifier(b.attr(),
                    new AttributeModifier(UpgradeData.RARITY_UUIDS[k], "Bench rarity bonus", b.amount(), b.op()));
        }

        // bônus aleatórios acumulados (retroativos à raridade atual)
        double[] sums = UpgradeData.getSums(tag);
        for (int k = 0; k < sums.length; k++) sums[k] *= rarity.bonusMult;
        for (int k = 0; k < sums.length; k++) {
            if (sums[k] == 0) continue;
            UpgradeData.Bonus b = UpgradeData.POOL.get(k);
            e.addModifier(b.attr(),
                    new AttributeModifier(UpgradeData.BONUS_UUIDS[k], "Bench bonus", sums[k], b.op()));
        }
    }
}
