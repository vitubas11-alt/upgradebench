package com.example.upgradebench;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = UpgradeBenchMod.MODID, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        CompoundTag t = e.getItemStack().getTag();
        if (t == null || t.getInt(UpgradeData.TAG) <= 0) return;
        BenchRarity r = BenchRarity.get(t.getInt(UpgradeData.RARITY));
        List<Component> tip = e.getToolTip();
        if (tip.isEmpty()) return;
        tip.set(0, tip.get(0).copy().withStyle(r.color)); // nome colorido pela raridade
        tip.add(Math.min(1, tip.size()), Component.literal(r.label + " — Upgrade Lv. " + t.getInt(UpgradeData.TAG))
                .withStyle(r.color, ChatFormatting.BOLD));
    }
}
