package com.example.upgradebench;

import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.DoubleTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

import java.util.List;
import java.util.UUID;

public class UpgradeData {
    public static final String TAG = "BenchLevel";
    public static final String ROLLS = "BenchRolls";   // formato antigo (migrado automaticamente)
    public static final String SUMS = "BenchBonusSums"; // total acumulado por tipo de bônus (tamanho fixo)
    public static final String RARITY = "BenchRarity"; // ordinal de BenchRarity

    // Ajuste à vontade
    public static final double FLAT_BASE = 1.0;        // dano flat do upgrade N = FLAT_BASE + N * FLAT_STEP
    public static final double FLAT_STEP = 0.5;
    public static final double MULT_PER_LEVEL = 0.05;  // cada nível multiplica o dano total por 1.05
    public static final double BONUS_SCALE = 0.10;     // bônus aleatório +10% mais forte por nível

    // Tag pra modpacks/datapacks adicionarem itens extras: data/upgradebench/tags/items/upgradable.json
    public static final TagKey<Item> UPGRADABLE =
            TagKey.create(Registries.ITEM, new ResourceLocation(UpgradeBenchMod.MODID, "upgradable"));

    public record Bonus(Attribute attr, double amount, Operation op) {}

    public static Bonus b(Attribute a, double v, Operation o) {
        return new Bonus(a, v, o);
    }

    public static final List<Bonus> POOL = List.of(
            new Bonus(Attributes.ATTACK_SPEED, 0.1, Operation.ADDITION),
            new Bonus(Attributes.MOVEMENT_SPEED, 0.03, Operation.MULTIPLY_BASE),
            new Bonus(Attributes.MAX_HEALTH, 2.0, Operation.ADDITION),
            new Bonus(Attributes.ARMOR, 1.0, Operation.ADDITION),
            new Bonus(Attributes.ARMOR_TOUGHNESS, 0.5, Operation.ADDITION),
            new Bonus(Attributes.LUCK, 0.5, Operation.ADDITION),
            new Bonus(Attributes.KNOCKBACK_RESISTANCE, 0.05, Operation.ADDITION),
            new Bonus(Attributes.ATTACK_KNOCKBACK, 0.3, Operation.ADDITION)
    );

    public static final UUID RARITY_MULT_UUID = UUID.nameUUIDFromBytes("upgradebench:raritymult".getBytes());
    public static final UUID[] RARITY_UUIDS = new UUID[16];
    static {
        for (int i = 0; i < RARITY_UUIDS.length; i++)
            RARITY_UUIDS[i] = UUID.nameUUIDFromBytes(("upgradebench:rarityfixed" + i).getBytes());
    }

    public static final UUID DAMAGE_UUID = UUID.nameUUIDFromBytes("upgradebench:damage".getBytes());
    public static final UUID MULT_UUID = UUID.nameUUIDFromBytes("upgradebench:mult".getBytes());
    public static final UUID[] BONUS_UUIDS = new UUID[POOL.size()];
    static {
        for (int i = 0; i < BONUS_UUIDS.length; i++)
            BONUS_UUIDS[i] = UUID.nameUUIDFromBytes(("upgradebench:bonus" + i).getBytes());
    }

    /** Totais acumulados por tipo de bônus. Tamanho fixo, não importa o nível. */
    public static double[] getSums(CompoundTag tag) {
        double[] s = new double[POOL.size()];
        if (tag.contains(SUMS, Tag.TAG_LIST)) {
            ListTag l = tag.getList(SUMS, Tag.TAG_DOUBLE);
            for (int i = 0; i < s.length && i < l.size(); i++) s[i] = l.getDouble(i);
        } else if (tag.contains(ROLLS)) { // migra itens do formato antigo
            for (int roll : tag.getIntArray(ROLLS)) {
                int idx = roll % 100, lv = roll / 100;
                if (idx >= 0 && idx < s.length) s[idx] += POOL.get(idx).amount() * (1 + lv * BONUS_SCALE);
            }
        }
        return s;
    }

    public static void saveSums(CompoundTag tag, double[] s) {
        ListTag l = new ListTag();
        for (double d : s) l.add(DoubleTag.valueOf(d));
        tag.put(SUMS, l);
        tag.remove(ROLLS);
    }

    /** Aceita armas/ferramentas vanilla e de qualquer mod. */
    public static boolean canUpgrade(ItemStack stack) {
        if (stack.isEmpty()) return false;
        Item item = stack.getItem();
        if (stack.is(UPGRADABLE)) return true;
        if (item instanceof BlockItem || item instanceof ArmorItem || stack.isEdible()) return false;
        // qualquer item (de qualquer mod) que dê dano de ataque na mão principal
        if (stack.getAttributeModifiers(EquipmentSlot.MAINHAND).containsKey(Attributes.ATTACK_DAMAGE)) return true;
        // arcos, bestas, cajados etc. de outros mods: item único e com durabilidade
        return stack.getMaxStackSize() == 1 && stack.isDamageableItem();
    }
}
