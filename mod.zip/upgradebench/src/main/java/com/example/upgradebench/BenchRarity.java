package com.example.upgradebench;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;

import static com.example.upgradebench.UpgradeData.b;

/**
 * Raridades. A cada upgrade existe uma chance (chanceNext) de subir pra próxima.
 * Raridade nunca desce. Cada raridade dá:
 *  - multiplicador de dano (dmgMult)
 *  - multiplicador nos bônus aleatórios (bonusMult), retroativo
 *  - número de bônus aleatórios por upgrade (rolls)
 *  - bônus fixos exclusivos (fixed)
 */
public enum BenchRarity {
    COMUM("Comum", ChatFormatting.WHITE, 1.00, 1.0, 1, 0.30),
    INCOMUM("Incomum", ChatFormatting.GREEN, 1.15, 1.25, 1, 0.22,
            b(Attributes.ATTACK_SPEED, 0.1, Operation.ADDITION)),
    RARO("Raro", ChatFormatting.BLUE, 1.35, 1.5, 1, 0.14,
            b(Attributes.ATTACK_SPEED, 0.2, Operation.ADDITION),
            b(Attributes.LUCK, 1.0, Operation.ADDITION)),
    EPICO("Épico", ChatFormatting.DARK_PURPLE, 1.65, 2.0, 2, 0.08,
            b(Attributes.ATTACK_SPEED, 0.3, Operation.ADDITION),
            b(Attributes.LUCK, 2.0, Operation.ADDITION),
            b(Attributes.MAX_HEALTH, 4.0, Operation.ADDITION)),
    LENDARIO("Lendário", ChatFormatting.GOLD, 2.10, 3.0, 2, 0.04,
            b(Attributes.ATTACK_SPEED, 0.5, Operation.ADDITION),
            b(Attributes.LUCK, 3.0, Operation.ADDITION),
            b(Attributes.MAX_HEALTH, 8.0, Operation.ADDITION),
            b(Attributes.ARMOR, 4.0, Operation.ADDITION),
            b(Attributes.KNOCKBACK_RESISTANCE, 0.2, Operation.ADDITION)),
    MITICO("Mítico", ChatFormatting.RED, 3.00, 4.0, 3, 0.015,
            b(Attributes.ATTACK_SPEED, 0.7, Operation.ADDITION),
            b(Attributes.LUCK, 5.0, Operation.ADDITION),
            b(Attributes.MAX_HEALTH, 16.0, Operation.ADDITION),
            b(Attributes.ARMOR, 8.0, Operation.ADDITION),
            b(Attributes.ARMOR_TOUGHNESS, 4.0, Operation.ADDITION),
            b(Attributes.MOVEMENT_SPEED, 0.15, Operation.MULTIPLY_BASE),
            b(Attributes.KNOCKBACK_RESISTANCE, 0.5, Operation.ADDITION)),
    DIVINO("Divino", ChatFormatting.AQUA, 5.00, 6.0, 4, 0.0,
            b(Attributes.ATTACK_SPEED, 1.0, Operation.ADDITION),
            b(Attributes.LUCK, 10.0, Operation.ADDITION),
            b(Attributes.MAX_HEALTH, 40.0, Operation.ADDITION),
            b(Attributes.ARMOR, 15.0, Operation.ADDITION),
            b(Attributes.ARMOR_TOUGHNESS, 8.0, Operation.ADDITION),
            b(Attributes.MOVEMENT_SPEED, 0.30, Operation.MULTIPLY_BASE),
            b(Attributes.KNOCKBACK_RESISTANCE, 1.0, Operation.ADDITION),
            b(Attributes.ATTACK_KNOCKBACK, 1.0, Operation.ADDITION));

    public final String label;
    public final ChatFormatting color;
    public final double dmgMult;
    public final double bonusMult;
    public final int rolls;
    public final double chanceNext;
    public final UpgradeData.Bonus[] fixed;

    BenchRarity(String label, ChatFormatting color, double dmgMult, double bonusMult,
                int rolls, double chanceNext, UpgradeData.Bonus... fixed) {
        this.label = label;
        this.color = color;
        this.dmgMult = dmgMult;
        this.bonusMult = bonusMult;
        this.rolls = rolls;
        this.chanceNext = chanceNext;
        this.fixed = fixed;
    }

    public static BenchRarity get(int ordinal) {
        BenchRarity[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, ordinal))];
    }
}
