package com.example.upgradebench;

import java.util.List;

import static com.example.upgradebench.BonusType.*;

/**
 * Cada categoria só pode ganhar bônus do próprio tipo.
 * A lista "pool" é usada pro sorteio e, na ordem, pros bônus fixos da raridade.
 */
public enum ItemCategory {
    WEAPON("Arma", List.of(ATTACK_SPEED, CRIT_CHANCE, LIFESTEAL, ENTITY_REACH, ATTACK_KNOCKBACK, MOVEMENT_SPEED)),
    TOOL("Ferramenta", List.of(BREAK_SPEED, BLOCK_REACH, LUCK, MOVEMENT_SPEED)),
    ARMOR("Armadura", List.of(BonusType.ARMOR, ARMOR_TOUGHNESS, MAX_HEALTH, KNOCKBACK_RESISTANCE, MOVEMENT_SPEED));

    public final String label;
    public final List<BonusType> pool;

    ItemCategory(String label, List<BonusType> pool) {
        this.label = label;
        this.pool = pool;
    }

    public static ItemCategory get(int ordinal) {
        ItemCategory[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, ordinal))];
    }
}
