package com.example.upgradebench;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class UpgradeBenchBlock extends Block {
    // Forja: base, coluna, mesa larga, placa dourada e cristal no topo
    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(2, 0, 2, 14, 3, 14),
            Block.box(4, 3, 4, 12, 8, 12),
            Block.box(0, 8, 0, 16, 12, 16),
            Block.box(1, 12, 1, 15, 13, 15),
            Block.box(6, 13, 6, 10, 16, 10));

    public UpgradeBenchBlock(Properties props) {
        super(props);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;

        ItemStack stack = player.getMainHandItem();
        ItemCategory cat = UpgradeData.categoryOf(stack);
        if (cat == null) {
            player.displayClientMessage(Component.literal("Segure uma arma, ferramenta ou armadura.")
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResult.SUCCESS;
        }

        CompoundTag tag = stack.getOrCreateTag();
        int lvl = tag.getInt(UpgradeData.TAG);
        int cost = Math.min(30, 1 + lvl / 2); // níveis de XP
        boolean creative = player.getAbilities().instabuild;

        if (!creative && player.experienceLevel < cost) {
            player.displayClientMessage(Component.literal("Precisa de " + cost + " níveis de XP.")
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResult.SUCCESS;
        }
        if (!creative) player.giveExperienceLevels(-cost);

        if (lvl == 0) {
            tag.putInt(UpgradeData.CAT, cat.ordinal());
            if (cat == ItemCategory.ARMOR)
                tag.putInt(UpgradeData.SLOT, Mob.getEquipmentSlotForItem(stack).ordinal());
        }
        int newLvl = lvl + 1;
        tag.putInt(UpgradeData.TAG, newLvl);

        // chance de subir de raridade
        BenchRarity rarity = BenchRarity.get(tag.getInt(UpgradeData.RARITY));
        boolean promoted = false;
        if (rarity.ordinal() < BenchRarity.values().length - 1
                && level.random.nextDouble() < rarity.chanceNext) {
            rarity = BenchRarity.get(rarity.ordinal() + 1);
            tag.putInt(UpgradeData.RARITY, rarity.ordinal());
            promoted = true;
        }

        // bônus aleatórios: só do tipo da categoria do item
        double[] sums = UpgradeData.getSums(tag);
        StringBuilder names = new StringBuilder();
        for (int i = 0; i < rarity.rolls; i++) {
            BonusType t = cat.pool.get(level.random.nextInt(cat.pool.size()));
            sums[t.ordinal()] += t.rollAmount * (1 + newLvl * UpgradeData.BONUS_SCALE);
            if (i > 0) names.append(", ");
            names.append(t.label);
        }
        UpgradeData.saveSums(tag, sums);

        level.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.8f, 1.2f);
        player.displayClientMessage(Component.literal(cat.label + " nível " + newLvl + "! Bônus: " + names)
                .withStyle(ChatFormatting.GREEN), true);

        if (promoted) {
            level.playSound(null, pos, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0f, 1.0f);
            if (rarity.ordinal() >= BenchRarity.MITICO.ordinal())
                level.playSound(null, pos, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 1.0f, 1.0f);
            if (level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, pos.getX() + 0.5, pos.getY() + 1.2,
                        pos.getZ() + 0.5, 20 + rarity.ordinal() * 15, 0.4, 0.4, 0.4, 0.3);
            }
            Component msg = Component.literal("★ " + player.getName().getString() + " elevou ")
                    .withStyle(ChatFormatting.YELLOW)
                    .append(stack.getHoverName().copy().withStyle(rarity.color))
                    .append(Component.literal(" para " + rarity.label.toUpperCase() + "! ★")
                            .withStyle(rarity.color, ChatFormatting.BOLD));
            if (rarity.ordinal() >= BenchRarity.LENDARIO.ordinal() && level.getServer() != null) {
                level.getServer().getPlayerList().broadcastSystemMessage(msg, false);
            } else {
                player.sendSystemMessage(msg);
            }
        }
        return InteractionResult.SUCCESS;
    }
}
