package com.example.upgradebench;

import net.minecraft.ChatFormatting;

/**
 * Raridades. A cada upgrade há uma chance (chanceNext) de subir pra próxima. Nunca desce.
 *  - dmgMult: multiplica o bônus principal (dano / mineração / armadura)
 *  - bonusMult: multiplica os bônus aleatórios (retroativo)
 *  - rolls: quantos bônus aleatórios por upgrade
 * Além disso, cada raridade desbloqueia bônus fixos exclusivos do tipo do item.
 */
public enum BenchRarity {
    COMUM("Comum", ChatFormatting.WHITE, 1.00, 1.0, 1, 0.30),
    INCOMUM("Incomum", ChatFormatting.GREEN, 1.15, 1.25, 1, 0.22),
    RARO("Raro", ChatFormatting.BLUE, 1.35, 1.5, 1, 0.14),
    EPICO("Épico", ChatFormatting.DARK_PURPLE, 1.65, 2.0, 2, 0.08),
    LENDARIO("Lendário", ChatFormatting.GOLD, 2.10, 3.0, 2, 0.04),
    MITICO("Mítico", ChatFormatting.RED, 3.00, 4.0, 3, 0.015),
    DIVINO("Divino", ChatFormatting.AQUA, 5.00, 6.0, 4, 0.0);

    public final String label;
    public final ChatFormatting color;
    public final double dmgMult;
    public final double bonusMult;
    public final int rolls;
    public final double chanceNext;

    BenchRarity(String label, ChatFormatting color, double dmgMult, double bonusMult, int rolls, double chanceNext) {
        this.label = label;
        this.color = color;
        this.dmgMult = dmgMult;
        this.bonusMult = bonusMult;
        this.rolls = rolls;
        this.chanceNext = chanceNext;
    }

    public static BenchRarity get(int ordinal) {
        BenchRarity[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, ordinal))];
    }
}
