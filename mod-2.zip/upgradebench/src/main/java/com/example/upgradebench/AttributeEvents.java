package com.example.upgradebench;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.event.ItemAttributeModifierEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Atributos aplicados por evento (compatível com itens de outros mods). */
@Mod.EventBusSubscriber(modid = UpgradeBenchMod.MODID)
public class AttributeEvents {
    @SubscribeEvent
    public static void onAttributes(ItemAttributeModifierEvent e) {
        CompoundTag tag = e.getItemStack().getTag();
        if (tag == null) return;
        int lvl = tag.getInt(UpgradeData.TAG);
        if (lvl <= 0) return;
        ItemCategory cat = ItemCategory.get(tag.getInt(UpgradeData.CAT));
        EquipmentSlot slot = UpgradeData.slotOf(tag, cat);
        if (e.getSlotType() != slot) return;
        BenchRarity rarity = BenchRarity.get(tag.getInt(UpgradeData.RARITY));
        String s = slot.getName();

        if (cat == ItemCategory.WEAPON) {
            e.addModifier(Attributes.ATTACK_DAMAGE, new AttributeModifier(UpgradeData.uuid("w_flat"),
                    "Bench damage", UpgradeData.flatDamage(lvl), Operation.ADDITION));
            e.addModifier(Attributes.ATTACK_DAMAGE, new AttributeModifier(UpgradeData.uuid("w_mult"),
                    "Bench multiplier", UpgradeData.multTotal(lvl) - 1, Operation.MULTIPLY_TOTAL));
            if (rarity.dmgMult > 1.0) {
                e.addModifier(Attributes.ATTACK_DAMAGE, new AttributeModifier(UpgradeData.uuid("w_rarity"),
                        "Bench rarity damage", rarity.dmgMult - 1.0, Operation.MULTIPLY_TOTAL));
            }
        } else if (cat == ItemCategory.ARMOR) {
            double p = rarity.dmgMult;
            e.addModifier(Attributes.ARMOR, new AttributeModifier(UpgradeData.uuid("a_armor:" + s),
                    "Bench armor",
                    (lvl * UpgradeData.ARMOR_BASE + UpgradeData.ARMOR_STEP * lvl * (lvl - 1) / 2.0) * p,
                    Operation.ADDITION));
            e.addModifier(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(UpgradeData.uuid("a_tough:" + s),
                    "Bench toughness",
                    (lvl * UpgradeData.TOUGH_BASE + UpgradeData.TOUGH_STEP * lvl * (lvl - 1) / 2.0) * p,
                    Operation.ADDITION));
            e.addModifier(Attributes.MAX_HEALTH, new AttributeModifier(UpgradeData.uuid("a_health:" + s),
                    "Bench health", lvl * UpgradeData.HEALTH_PER_LEVEL * p, Operation.ADDITION));
        }
        // ferramenta: bônus principal (mineração) é aplicado em CustomEvents

        double[] stats = UpgradeData.stats(tag, cat, rarity);
        for (BonusType t : BonusType.values()) {
            double v = stats[t.ordinal()];
            if (t.isCustom() || v == 0) continue;
            e.addModifier(t.attr.get(), new AttributeModifier(UpgradeData.uuid("b:" + t.name() + ":" + s),
                    "Bench " + t.name(), v, t.op));
        }
    }
}
