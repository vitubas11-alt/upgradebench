package com.example.upgradebench;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Bônus que não são atributos do Minecraft: mineração, crítico, roubo de vida e dano de projéteis. */
@Mod.EventBusSubscriber(modid = UpgradeBenchMod.MODID)
public class CustomEvents {

    @SubscribeEvent
    public static void onBreakSpeed(PlayerEvent.BreakSpeed e) {
        ItemStack st = e.getEntity().getMainHandItem();
        CompoundTag tag = st.getTag();
        if (tag == null) return;
        int lvl = tag.getInt(UpgradeData.TAG);
        if (lvl <= 0 || ItemCategory.get(tag.getInt(UpgradeData.CAT)) != ItemCategory.TOOL) return;
        BenchRarity r = BenchRarity.get(tag.getInt(UpgradeData.RARITY));
        double[] s = UpgradeData.stats(tag, ItemCategory.TOOL, r);
        double mult = Math.min(Math.pow(1 + UpgradeData.TOOL_MULT_PER_LEVEL, lvl), 1.0e6)
                * r.dmgMult * (1 + s[BonusType.BREAK_SPEED.ordinal()]);
        e.setNewSpeed((float) (e.getNewSpeed() * mult));
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getSource().getEntity() instanceof LivingEntity attacker)) return;
        CompoundTag tag = attacker.getMainHandItem().getTag();
        if (tag == null) return;
        int lvl = tag.getInt(UpgradeData.TAG);
        if (lvl <= 0 || ItemCategory.get(tag.getInt(UpgradeData.CAT)) != ItemCategory.WEAPON) return;
        BenchRarity r = BenchRarity.get(tag.getInt(UpgradeData.RARITY));
        double[] s = UpgradeData.stats(tag, ItemCategory.WEAPON, r);

        double amount = e.getAmount();
        // arcos/bestas/tridentes: o atributo de dano não vale pra projétil, então aplicamos aqui
        if (e.getSource().getDirectEntity() instanceof Projectile) {
            amount = (amount + UpgradeData.flatDamage(lvl)) * UpgradeData.multTotal(lvl) * r.dmgMult;
        }
        if (attacker.getRandom().nextDouble() < s[BonusType.CRIT_CHANCE.ordinal()]) amount *= 2.0;
        e.setAmount((float) amount);

        double ls = s[BonusType.LIFESTEAL.ordinal()];
        if (ls > 0) attacker.heal((float) (amount * Math.min(ls, 1.0)));
    }
}
