package com.example.upgradebench;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = UpgradeBenchMod.MODID, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent e) {
        CompoundTag t = e.getItemStack().getTag();
        if (t == null) return;
        int lvl = t.getInt(UpgradeData.TAG);
        if (lvl <= 0) return;
        List<Component> tip = e.getToolTip();
        if (tip.isEmpty()) return;

        BenchRarity r = BenchRarity.get(t.getInt(UpgradeData.RARITY));
        ItemCategory cat = ItemCategory.get(t.getInt(UpgradeData.CAT));
        tip.set(0, tip.get(0).copy().withStyle(r.color));

        int pos = Math.min(1, tip.size());
        tip.add(pos++, Component.literal(r.label + " " + cat.label + " — Lv. " + lvl)
                .withStyle(r.color, ChatFormatting.BOLD));

        // bônus que não aparecem como atributo do Minecraft
        double[] s = UpgradeData.stats(t, cat, r);
        if (cat == ItemCategory.TOOL) {
            double mult = Math.min(Math.pow(1 + UpgradeData.TOOL_MULT_PER_LEVEL, lvl), 1.0e6)
                    * r.dmgMult * (1 + s[BonusType.BREAK_SPEED.ordinal()]);
            tip.add(pos++, Component.literal(String.format("Mineração x%.1f", mult)).withStyle(ChatFormatting.GREEN));
        }
        for (BonusType bt : BonusType.values()) {
            double v = s[bt.ordinal()];
            if (!bt.isCustom() || bt == BonusType.BREAK_SPEED || v <= 0) continue;
            tip.add(pos++, Component.literal(String.format("+%.0f%% %s", v * 100, bt.label))
                    .withStyle(ChatFormatting.BLUE));
        }
    }
}
