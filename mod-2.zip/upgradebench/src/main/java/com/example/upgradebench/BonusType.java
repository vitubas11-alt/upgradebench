package com.example.upgradebench;

import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.common.ForgeMod;

import java.util.function.Supplier;

/** Tipos de bônus. attr == null significa bônus "customizado" (tratado por eventos). */
public enum BonusType {
    // armas
    ATTACK_SPEED("Velocidade de ataque", () -> Attributes.ATTACK_SPEED, Operation.ADDITION, 0.10, 1.0),
    CRIT_CHANCE("Chance de crítico (x2)", null, null, 0.01, 0.30),
    LIFESTEAL("Roubo de vida", null, null, 0.01, 0.15),
    ENTITY_REACH("Alcance de ataque", () -> ForgeMod.ENTITY_REACH.get(), Operation.ADDITION, 0.15, 1.5),
    ATTACK_KNOCKBACK("Repulsão", () -> Attributes.ATTACK_KNOCKBACK, Operation.ADDITION, 0.30, 1.0),
    // ferramentas
    BREAK_SPEED("Velocidade de mineração", null, null, 0.10, 2.0),
    BLOCK_REACH("Alcance de blocos", () -> ForgeMod.BLOCK_REACH.get(), Operation.ADDITION, 0.20, 3.0),
    LUCK("Sorte", () -> Attributes.LUCK, Operation.ADDITION, 0.50, 10.0),
    // armaduras
    ARMOR("Armadura", () -> Attributes.ARMOR, Operation.ADDITION, 1.0, 6.0),
    ARMOR_TOUGHNESS("Resistência da armadura", () -> Attributes.ARMOR_TOUGHNESS, Operation.ADDITION, 0.5, 3.0),
    MAX_HEALTH("Vida máxima", () -> Attributes.MAX_HEALTH, Operation.ADDITION, 2.0, 10.0),
    KNOCKBACK_RESISTANCE("Resistência a repulsão", () -> Attributes.KNOCKBACK_RESISTANCE, Operation.ADDITION, 0.05, 0.25),
    // compartilhado
    MOVEMENT_SPEED("Velocidade de movimento", () -> Attributes.MOVEMENT_SPEED, Operation.MULTIPLY_BASE, 0.03, 0.10);

    public final String label;
    public final Supplier<Attribute> attr;
    public final Operation op;
    public final double rollAmount; // valor base de cada sorteio
    public final double fixedMax;   // valor máximo do bônus fixo (raridade Divina)

    BonusType(String label, Supplier<Attribute> attr, Operation op, double rollAmount, double fixedMax) {
        this.label = label;
        this.attr = attr;
        this.op = op;
        this.rollAmount = rollAmount;
        this.fixedMax = fixedMax;
    }

    public boolean isCustom() {
        return attr == null;
    }
}
