package com.example.upgradebench;

import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.DoubleTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class UpgradeData {
    public static final String TAG = "BenchLevel";
    public static final String RARITY = "BenchRarity";
    public static final String CAT = "BenchCat";
    public static final String SLOT = "BenchSlot";
    public static final String STATS = "BenchStats";

    // ===== Ajuste à vontade =====
    // ARMA: dano flat do upgrade N = FLAT_BASE + N * FLAT_STEP, e cada nível multiplica o dano por (1 + MULT_PER_LEVEL)
    public static final double FLAT_BASE = 1.0;
    public static final double FLAT_STEP = 0.5;
    public static final double MULT_PER_LEVEL = 0.05;
    // FERRAMENTA: cada nível multiplica a velocidade de mineração
    public static final double TOOL_MULT_PER_LEVEL = 0.07;
    // ARMADURA (por peça): armadura, resistência e vida por nível
    public static final double ARMOR_BASE = 0.3, ARMOR_STEP = 0.05;
    public static final double TOUGH_BASE = 0.15, TOUGH_STEP = 0.025;
    public static final double HEALTH_PER_LEVEL = 0.5;
    // bônus aleatório fica +10% mais forte por nível
    public static final double BONUS_SCALE = 0.10;

    // Tags pra forçar a categoria de itens de outros mods (datapack/KubeJS)
    public static final TagKey<Item> WEAPONS = tag("weapons");
    public static final TagKey<Item> TOOLS = tag("tools");
    public static final TagKey<Item> ARMORS = tag("armors");

    private static TagKey<Item> tag(String name) {
        return TagKey.create(Registries.ITEM, new ResourceLocation(UpgradeBenchMod.MODID, name));
    }

    private static final Map<String, UUID> UUIDS = new ConcurrentHashMap<>();

    public static UUID uuid(String key) {
        return UUIDS.computeIfAbsent(key,
                k -> UUID.nameUUIDFromBytes(("upgradebench:" + k).getBytes(StandardCharsets.UTF_8)));
    }

    public static double flatDamage(int lvl) {
        return lvl * FLAT_BASE + FLAT_STEP * lvl * (lvl - 1) / 2.0;
    }

    public static double multTotal(int lvl) {
        return Math.min(Math.pow(1 + MULT_PER_LEVEL, lvl), 1.0e9);
    }

    /** Descobre a categoria do item (null = não aceito). Funciona com itens de outros mods. */
    public static ItemCategory categoryOf(ItemStack stack) {
        if (stack.isEmpty()) return null;
        CompoundTag tag = stack.getTag();
        if (tag != null && tag.getInt(TAG) > 0) return ItemCategory.get(tag.getInt(CAT)); // já upgradeado
        if (stack.is(ARMORS)) return ItemCategory.ARMOR;
        if (stack.is(TOOLS)) return ItemCategory.TOOL;
        if (stack.is(WEAPONS)) return ItemCategory.WEAPON;
        Item item = stack.getItem();
        if (item instanceof BlockItem || stack.isEdible()) return null;
        if (item instanceof ArmorItem || Mob.getEquipmentSlotForItem(stack).getType() == EquipmentSlot.Type.ARMOR)
            return ItemCategory.ARMOR;
        if (item instanceof DiggerItem) return ItemCategory.TOOL;
        if (item instanceof SwordItem || item instanceof TridentItem || item instanceof ProjectileWeaponItem)
            return ItemCategory.WEAPON;
        if (stack.getAttributeModifiers(EquipmentSlot.MAINHAND).containsKey(Attributes.ATTACK_DAMAGE))
            return ItemCategory.WEAPON;
        if (stack.getMaxStackSize() == 1 && stack.isDamageableItem()) return ItemCategory.TOOL;
        return null;
    }

    public static EquipmentSlot slotOf(CompoundTag tag, ItemCategory cat) {
        if (cat != ItemCategory.ARMOR) return EquipmentSlot.MAINHAND;
        EquipmentSlot[] v = EquipmentSlot.values();
        return v[Math.max(0, Math.min(v.length - 1, tag.getInt(SLOT)))];
    }

    /** Totais sorteados acumulados por tipo de bônus. Tamanho fixo, não importa o nível. */
    public static double[] getSums(CompoundTag tag) {
        double[] s = new double[BonusType.values().length];
        if (tag.contains(STATS, Tag.TAG_LIST)) {
            ListTag l = tag.getList(STATS, Tag.TAG_DOUBLE);
            for (int i = 0; i < s.length && i < l.size(); i++) s[i] = l.getDouble(i);
        }
        return s;
    }

    public static void saveSums(CompoundTag tag, double[] s) {
        ListTag l = new ListTag();
        for (double d : s) l.add(DoubleTag.valueOf(d));
        tag.put(STATS, l);
    }

    /** Valor final de cada bônus (sorteados x raridade + fixos da raridade). */
    public static double[] stats(CompoundTag tag, ItemCategory cat, BenchRarity rarity) {
        double[] s = getSums(tag);
        for (int i = 0; i < s.length; i++) s[i] *= rarity.bonusMult;
        int unlocked = rarity.ordinal();
        for (int i = 0; i < cat.pool.size() && i < unlocked; i++) {
            BonusType t = cat.pool.get(i);
            s[t.ordinal()] += t.fixedMax * rarity.ordinal() / 6.0;
        }
        return s;
    }
}
